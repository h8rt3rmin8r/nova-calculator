Welcome to...
_______________________________________________
:::.    :::.    ...    :::      .::.:::.     
`;;;;,  `;;; .;;;;;;;. ';;,   ,;;;' ;;`;;    
  [[[[[. '[[,[[     \[[,\[[  .[[/  ,[[ '[[,  
  $$$ "Y$c$$$$$,     $$$ Y$c.$$"  c$$$cc$$$c 
  888    Y88"888,_ _,88P  Y88P     888   888,
  MMM     YM  "YMMMMMP"    MP      YMM   ""` 
           _            _       _             
  ___ __ _| | ___ _   _| | __ _| |_ ___  _ __ 
 / __/ _` | |/ __| | | | |/ _` | __/ _ \| '__|
| (_| (_| | | (__| |_| | | (_| | || (_) | |   
 \___\__,_|_|\___|\__,_|_|\__,_|\__\___/|_|   
_______________________________________________

DESCRIPTION:

Nova calculator allows floating point arithmetic to be executed in bash in a faster
and more efficient manner than is currently possible with existing bash tools.

_______________________________________________

ATTRIBUTION:

Nova was created by the following developers...

	- kryptomuncher
	- brettwy861
	- h8rt3rmin8r

_______________________________________________

DEPENDANCIES:

	- Python 2.7
	- Python module: "Decimal"

_______________________________________________

FEEDBACK & BUG REPORTS:

(Email) 161803398@email.tg

_______________________________________________
